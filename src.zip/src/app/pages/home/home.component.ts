import { Component } from '@angular/core';
import { Title } from '@angular/platform-browser';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [],
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent {
dist=
[
{
  id :1,
  title:"Malappuram",
  image:"",
  discription:"hhhhhhh"
},
{
  id :2,
  title:"Ernakulam",
  image:"",
  discription:"hhhhhhh"
},
{
  id :3,
  title:"TVM",
  image:"",
  discription:"hhhhhhh"
}
]
}
